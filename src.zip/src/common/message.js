export default function(that,msg,type){
	that.$message({
     	message: msg,
     	type: type
    });
}